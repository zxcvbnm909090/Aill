import 'package:flutter/foundation.dart';
import 'package:flutter_v2ray/flutter_v2ray.dart';
import '../models/vpn_profile.dart';

enum VpnConnectionState { disconnected, connecting, connected, error }

/// طبقة تجريد فوق حزمة flutter_v2ray (تغلّف Xray-core).
/// تتعامل مع رابط الاشتراك (vless/vmess/trojan) مباشرة، بما فيها
/// باراميتر SNI المضمّن داخل الرابط لتجاوز الحجب.
class V2RayService extends ChangeNotifier {
  late final FlutterV2ray _v2ray;

  VpnConnectionState state = VpnConnectionState.disconnected;
  String? lastError;

  V2RayService() {
    _v2ray = FlutterV2ray(
      onStatusChanged: (status) {
        // status.state مثل: CONNECTED / DISCONNECTED حسب الحزمة
        _handleStatus(status);
      },
    );
  }

  Future<void> init() async {
    await _v2ray.initializeV2Ray();
  }

  /// يحوّل رابط الاشتراك (vless://..., vmess://..., trojan://...) إلى
  /// إعدادات V2Ray قابلة للتشغيل، مع الحفاظ على SNI من الرابط نفسه
  /// (الباراميتر sni= أو host= في الرابط يُستخدم تلقائيًا من الحزمة).
  Future<void> connect(VpnProfile profile) async {
    try {
      state = VpnConnectionState.connecting;
      notifyListeners();

      final parsed = V2RayURL.parseFromURL(profile.configLink);

      final hasPermission = await _v2ray.requestPermission();
      if (!hasPermission) {
        state = VpnConnectionState.error;
        lastError = 'لم يتم منح صلاحية VPN';
        notifyListeners();
        return;
      }

      await _v2ray.startV2Ray(
        remark: profile.name,
        config: parsed.getFullConfiguration(),
        proxyOnly: false,
        bypassSubnets: null,
      );
    } catch (e) {
      state = VpnConnectionState.error;
      lastError = e.toString();
      notifyListeners();
    }
  }

  Future<void> disconnect() async {
    await _v2ray.stopV2Ray();
    state = VpnConnectionState.disconnected;
    notifyListeners();
  }

  /// فحص سرعة/زمن استجابة بروفايل معيّن قبل أو أثناء الاتصال.
  Future<int> ping(VpnProfile profile) async {
    try {
      final parsed = V2RayURL.parseFromURL(profile.configLink);
      final delay = await _v2ray.getServerDelay(
        config: parsed.getFullConfiguration(),
      );
      return delay; // بالميلي ثانية، -1 إذا فشل الفحص
    } catch (_) {
      return -1;
    }
  }

  void _handleStatus(dynamic status) {
    // عدّل حسب الشكل الفعلي لـ V2RayStatus في نسخة الحزمة المستخدمة
    final raw = status.toString().toUpperCase();
    if (raw.contains('CONNECTED')) {
      state = VpnConnectionState.connected;
    } else if (raw.contains('DISCONNECTED') || raw.contains('IDLE')) {
      state = VpnConnectionState.disconnected;
    }
    notifyListeners();
  }
}
