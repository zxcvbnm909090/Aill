/// يمثل بروفايل اتصال V2Ray واحد.
/// يُضاف يدويًا من المستخدم (عبر رابط vless/vmess/trojan أو إدخال يدوي للحقول).
class VpnProfile {
  final String id;
  final String name;

  /// رابط الاشتراك الكامل (vless://, vmess://, trojan://...)
  final String configLink;

  /// المضيف — يُستخرج من الرابط لعرضه في الواجهة فقط
  final String host;
  final int port;

  /// SNI المستخدم لتجاوز الحجب (Server Name Indication)
  final String? sni;

  /// آخر نتيجة فحص سرعة (ms) — null إذا لم يُفحص بعد
  final int? lastPingMs;

  final bool isFavorite;

  /// تفعيل تمرير بروتوكول UDP عبر النفق (مفيد للألعاب والمكالمات الصوتية/الفيديو).
  /// مفعّل افتراضيًا.
  final bool enableUdp;

  const VpnProfile({
    required this.id,
    required this.name,
    required this.configLink,
    required this.host,
    required this.port,
    this.sni,
    this.lastPingMs,
    this.isFavorite = false,
    this.enableUdp = true,
  });

  VpnProfile copyWith({
    String? name,
    int? lastPingMs,
    bool? isFavorite,
    bool? enableUdp,
  }) {
    return VpnProfile(
      id: id,
      name: name ?? this.name,
      configLink: configLink,
      host: host,
      port: port,
      sni: sni,
      lastPingMs: lastPingMs ?? this.lastPingMs,
      isFavorite: isFavorite ?? this.isFavorite,
      enableUdp: enableUdp ?? this.enableUdp,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'configLink': configLink,
        'host': host,
        'port': port,
        'sni': sni,
        'lastPingMs': lastPingMs,
        'isFavorite': isFavorite,
        'enableUdp': enableUdp,
      };

  factory VpnProfile.fromJson(Map<String, dynamic> json) => VpnProfile(
        id: json['id'] as String,
        name: json['name'] as String,
        configLink: json['configLink'] as String,
        host: json['host'] as String,
        port: json['port'] as int,
        sni: json['sni'] as String?,
        lastPingMs: json['lastPingMs'] as int?,
        isFavorite: json['isFavorite'] as bool? ?? false,
        enableUdp: json['enableUdp'] as bool? ?? true,
      );
}
