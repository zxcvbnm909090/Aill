package com.mahmoudvpn.app
import android.net.VpnService

// نقطة تأسيس لخدمة VPN. لا يبدأ نفقاً فعلياً قبل إضافة بروتوكول وخادم وبيانات اتصال صحيحة.
class MyVpnService : VpnService()
