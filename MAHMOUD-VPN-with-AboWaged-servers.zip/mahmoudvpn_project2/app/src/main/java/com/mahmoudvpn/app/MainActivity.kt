package com.mahmoudvpn.app

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import org.json.JSONArray

class MainActivity : Activity() {
    private val requestVpn = 701
    private lateinit var status: TextView
    private lateinit var connect: Button
    private lateinit var serverSpinner: Spinner
    private var serverConfigs: List<String> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val blue = Color.rgb(4, 119, 190)
        window.statusBarColor = blue
        window.navigationBarColor = Color.BLACK

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(Color.WHITE)
        }
        page.addView(TextView(this).apply {
            text = "MAHMOUD VPN"
            textSize = 28f
            setTextColor(blue)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 12)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        page.addView(TextView(this).apply {
            text = "اتصال آمن وسهل"
            textSize = 16f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
        })
        status = TextView(this).apply {
            text = "VPN IS OFF"
            textSize = 25f
            setTextColor(blue)
            gravity = Gravity.CENTER
            setPadding(0, 48, 0, 24)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        page.addView(status)
        page.addView(TextView(this).apply {
            text = "اختر موقع الخادم"
            textSize = 16f
            setTextColor(Color.BLACK)
        })
        val servers = loadServers()
        serverConfigs = servers.map { it.second }
        serverSpinner = Spinner(this)
        serverSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            servers.map { it.first })
        page.addView(serverSpinner)
        page.addView(TextView(this).apply {
            text = "تم استيراد ${servers.size} خادم من ملف AboWaged VPN"
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(0, 8, 0, 0)
        })

        connect = Button(this).apply {
            text = "START"
            textSize = 18f
            setTextColor(Color.WHITE)
            setBackgroundColor(blue)
            setPadding(30, 18, 30, 18)
            setOnClickListener { requestConnectionPermission() }
        }
        page.addView(connect, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 42 })

        page.addView(TextView(this).apply {
            text = "تم استيراد قائمة الخوادم. تشغيل VLESS الفعلي يحتاج دمج محرك اتصال متوافق."
            textSize = 13f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(8, 30, 8, 0)
        })
        setContentView(page)
    }

    private fun loadServers(): List<Pair<String, String>> {
        return try {
            val raw = assets.open("servers.json").bufferedReader().use { it.readText() }
            val array = JSONArray(raw)
            (0 until array.length()).map { index ->
                val item = array.getJSONObject(index)
                item.getString("name") to item.getString("config")
            }
        } catch (_: Exception) {
            listOf("لا توجد خوادم" to "")
        }
    }

    private fun requestConnectionPermission() {
        val intent = VpnService.prepare(this)
        if (intent != null) startActivityForResult(intent, requestVpn)
        else onActivityResult(requestVpn, RESULT_OK, null)
    }

    @Deprecated("Deprecated API retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestVpn && resultCode == RESULT_OK) {
            status.text = "VPN PERMISSION GRANTED"
            connect.text = "CONFIG SELECTED"
            val selected = serverSpinner.selectedItem?.toString() ?: "الخادم"
            Toast.makeText(this, "تم اختيار $selected. يلزم دمج محرك VLESS لتشغيل الاتصال الفعلي.", Toast.LENGTH_LONG).show()
        } else if (requestCode == requestVpn) {
            Toast.makeText(this, "لم يتم منح إذن VPN", Toast.LENGTH_SHORT).show()
        }
    }
}
