import 'package:flutter/material.dart';
import '../models/vpn_profile.dart';
import '../services/profile_repository.dart';
import 'add_profile_screen.dart';

class ProfilesScreen extends StatefulWidget {
  const ProfilesScreen({super.key});

  @override
  State<ProfilesScreen> createState() => _ProfilesScreenState();
}

class _ProfilesScreenState extends State<ProfilesScreen> {
  final _repository = ProfileRepository();
  List<VpnProfile> _profiles = [];

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final all = await _repository.getAll();
    setState(() => _profiles = all);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('البروفايلات'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AddProfileScreen()),
              );
              _refresh();
            },
          ),
        ],
      ),
      body: _profiles.isEmpty
          ? const Center(child: Text('لا يوجد بروفايلات بعد. اضغط + للإضافة'))
          : ListView.builder(
              itemCount: _profiles.length,
              itemBuilder: (context, index) {
                final p = _profiles[index];
                return ListTile(
                  leading: const Icon(Icons.dns_outlined),
                  title: Text(p.name),
                  subtitle: Text('${p.host}:${p.port}'
                      '${p.sni != null ? ' • SNI: ${p.sni}' : ''}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () async {
                      await _repository.delete(p.id);
                      _refresh();
                    },
                  ),
                  onTap: () => Navigator.pop(context, p),
                );
              },
            ),
    );
  }
}
