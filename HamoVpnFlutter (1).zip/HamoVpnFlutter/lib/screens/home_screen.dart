import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/v2ray_service.dart';
import '../services/profile_repository.dart';
import '../models/vpn_profile.dart';
import 'profiles_screen.dart';
import 'speed_test_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _repository = ProfileRepository();
  VpnProfile? _selectedProfile;

  @override
  void initState() {
    super.initState();
    _loadLastProfile();
  }

  Future<void> _loadLastProfile() async {
    final all = await _repository.getAll();
    if (all.isNotEmpty) {
      setState(() => _selectedProfile = all.first);
    }
  }

  @override
  Widget build(BuildContext context) {
    final v2ray = context.watch<V2RayService>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Hamo VPN'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          const SizedBox(height: 24),
          _buildStatusText(v2ray.state),
          const SizedBox(height: 32),
          _buildConnectButton(v2ray),
          const SizedBox(height: 32),
          if (_selectedProfile != null) _buildSelectedProfileCard(),
          const Spacer(),
          _buildBottomActions(),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildStatusText(VpnConnectionState state) {
    final (text, color) = switch (state) {
      VpnConnectionState.connected => ('متصل', Colors.green),
      VpnConnectionState.connecting => ('جاري الاتصال...', Colors.orange),
      VpnConnectionState.error => ('خطأ بالاتصال', Colors.red),
      VpnConnectionState.disconnected => ('غير متصل', Colors.grey),
    };
    return Text(
      text,
      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: color),
    );
  }

  Widget _buildConnectButton(V2RayService v2ray) {
    final isConnected = v2ray.state == VpnConnectionState.connected;
    final isConnecting = v2ray.state == VpnConnectionState.connecting;

    return GestureDetector(
      onTap: _selectedProfile == null
          ? null
          : () async {
              if (isConnected) {
                await v2ray.disconnect();
              } else {
                await v2ray.connect(_selectedProfile!);
              }
            },
      child: Container(
        width: 140,
        height: 140,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: isConnected
              ? Colors.green.withOpacity(0.15)
              : Theme.of(context).colorScheme.primary.withOpacity(0.1),
          border: Border.all(
            color: isConnected ? Colors.green : Theme.of(context).colorScheme.primary,
            width: 2,
          ),
        ),
        child: Center(
          child: isConnecting
              ? const CircularProgressIndicator()
              : Icon(
                  Icons.power_settings_new,
                  size: 54,
                  color: isConnected ? Colors.green : Theme.of(context).colorScheme.primary,
                ),
        ),
      ),
    );
  }

  Widget _buildSelectedProfileCard() {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 24),
      child: ListTile(
        leading: const Icon(Icons.dns_outlined),
        title: Text(_selectedProfile!.name),
        subtitle: Text(_selectedProfile!.host),
        trailing: TextButton(
          onPressed: () async {
            final profile = await Navigator.push<VpnProfile>(
              context,
              MaterialPageRoute(builder: (_) => const ProfilesScreen()),
            );
            if (profile != null) setState(() => _selectedProfile = profile);
          },
          child: const Text('تغيير'),
        ),
      ),
    );
  }

  Widget _buildBottomActions() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _bottomAction(Icons.list_alt, 'البروفايلات', () async {
          final profile = await Navigator.push<VpnProfile>(
            context,
            MaterialPageRoute(builder: (_) => const ProfilesScreen()),
          );
          if (profile != null) setState(() => _selectedProfile = profile);
        }),
        _bottomAction(Icons.speed, 'فحص السرعة', () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const SpeedTestScreen()),
          );
        }),
      ],
    );
  }

  Widget _bottomAction(IconData icon, String label, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Icon(icon),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(fontSize: 12)),
          ],
        ),
      ),
    );
  }
}
