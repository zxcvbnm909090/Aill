import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/vpn_profile.dart';
import '../services/profile_repository.dart';

/// إضافة بروفايل عبر لصق رابط اشتراك V2Ray كامل (vless://, vmess://, trojan://).
/// الرابط نفسه يحمل عادة عنوان المضيف، المنفذ، وباراميتر SNI إن وُجد.
class AddProfileScreen extends StatefulWidget {
  const AddProfileScreen({super.key});

  @override
  State<AddProfileScreen> createState() => _AddProfileScreenState();
}

class _AddProfileScreenState extends State<AddProfileScreen> {
  final _nameController = TextEditingController();
  final _linkController = TextEditingController();
  final _repository = ProfileRepository();
  String? _error;

  Future<void> _save() async {
    final name = _nameController.text.trim();
    final link = _linkController.text.trim();

    if (name.isEmpty || link.isEmpty) {
      setState(() => _error = 'الرجاء تعبئة كل الحقول');
      return;
    }

    Uri uri;
    try {
      uri = Uri.parse(link);
    } catch (_) {
      setState(() => _error = 'رابط غير صالح');
      return;
    }

    if (!['vless', 'vmess', 'trojan'].contains(uri.scheme)) {
      setState(() => _error = 'الرابط يجب أن يبدأ بـ vless:// أو vmess:// أو trojan://');
      return;
    }

    final sni = uri.queryParameters['sni'];

    final profile = VpnProfile(
      id: const Uuid().v4(),
      name: name,
      configLink: link,
      host: uri.host,
      port: uri.port,
      sni: sni,
    );

    await _repository.add(profile);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إضافة بروفايل')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'اسم البروفايل'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _linkController,
              maxLines: 4,
              decoration: const InputDecoration(
                labelText: 'رابط الاشتراك (vless:// أو vmess:// أو trojan://)',
                alignLabelWithHint: true,
              ),
            ),
            if (_error != null) ...[
              const SizedBox(height: 8),
              Text(_error!, style: const TextStyle(color: Colors.red)),
            ],
            const SizedBox(height: 20),
            FilledButton(onPressed: _save, child: const Text('حفظ')),
          ],
        ),
      ),
    );
  }
}
