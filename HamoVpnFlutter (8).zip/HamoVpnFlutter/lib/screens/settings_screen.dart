import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../services/update_service.dart';
import '../services/subscription_service.dart';
import '../services/profile_repository.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _updateService = UpdateService();
  final _subscriptionService = SubscriptionService();
  final _profileRepository = ProfileRepository();
  final _subscriptionUrlController = TextEditingController();

  bool _checkingUpdate = false;
  bool _syncingSubscription = false;
  String? _subscriptionMessage;
  bool _subscriptionSuccess = false;

  @override
  void initState() {
    super.initState();
    _loadSavedSubscriptionUrl();
  }

  Future<void> _loadSavedSubscriptionUrl() async {
    final saved = await _subscriptionService.getSavedUrl();
    if (saved != null && mounted) {
      _subscriptionUrlController.text = saved;
    }
  }

  Future<void> _syncSubscription() async {
    final url = _subscriptionUrlController.text.trim();
    if (url.isEmpty) {
      setState(() {
        _subscriptionSuccess = false;
        _subscriptionMessage = 'الصق رابط JSON صالح أولاً';
      });
      return;
    }

    setState(() {
      _syncingSubscription = true;
      _subscriptionMessage = null;
    });

    try {
      final profiles = await _subscriptionService.fetchProfiles(url);
      final groups = profiles.map((p) => p.group).toSet();
      await _profileRepository.replaceGroups(groups, profiles);
      await _subscriptionService.saveUrl(url);

      setState(() {
        _subscriptionSuccess = true;
        _subscriptionMessage = 'تم تحديث ${profiles.length} سيرفر بنجاح';
      });
    } catch (e) {
      setState(() {
        _subscriptionSuccess = false;
        _subscriptionMessage = e.toString().replaceFirst('Exception: ', '');
      });
    } finally {
      setState(() => _syncingSubscription = false);
    }
  }

  Future<void> _checkUpdate() async {
    setState(() => _checkingUpdate = true);
    final info = await _updateService.checkForUpdate();
    setState(() => _checkingUpdate = false);

    if (!mounted) return;

    if (info == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('أنت تستخدم آخر إصدار')),
      );
    } else {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text('تحديث جديد: ${info.latestVersion}'),
          content: Text(info.notes.isEmpty ? 'يتوفر إصدار أحدث من التطبيق' : info.notes),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('لاحقًا')),
            FilledButton(
              onPressed: () {
                // افتح info.apkUrl عبر url_launcher في التنفيذ النهائي
                Navigator.pop(context);
              },
              child: const Text('تحديث الآن'),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<ThemeProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        children: [
          SwitchListTile(
            title: const Text('الوضع الليلي'),
            value: themeProvider.mode == ThemeMode.dark,
            onChanged: (val) => themeProvider.toggle(val),
          ),
          ListTile(
            title: const Text('التحقق من وجود تحديث'),
            trailing: _checkingUpdate
                ? const SizedBox(
                    width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.chevron_left),
            onTap: _checkingUpdate ? null : _checkUpdate,
          ),
          const Divider(height: 32),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'تحديث السيرفرات من رابط (Subscription)',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 4),
                const Text(
                  'ضع رابط ملف JSON (مثلاً رابط GitHub Raw) يحوي قائمة '
                  'سيرفراتك، وسيُحدَّث التطبيق منه عند الضغط على "تحديث الآن".',
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _subscriptionUrlController,
                  decoration: const InputDecoration(
                    labelText: 'رابط JSON',
                    hintText: 'https://raw.githubusercontent.com/.../servers.json',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                ),
                if (_subscriptionMessage != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    _subscriptionMessage!,
                    style: TextStyle(
                      color: _subscriptionSuccess ? Colors.green : Colors.red,
                    ),
                  ),
                ],
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: _syncingSubscription ? null : _syncSubscription,
                  icon: _syncingSubscription
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.sync),
                  label: Text(_syncingSubscription ? 'جاري التحديث...' : 'تحديث الآن'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
