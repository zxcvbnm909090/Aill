import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/vpn_profile.dart';
import '../services/profile_repository.dart';
import '../services/link_parser.dart';

/// إضافة عدة بروفايلات دفعة واحدة: رابط اشتراك واحد بكل سطر،
/// مع تصنيفها تحت مجموعة واحدة (مثل "منزل"، "عمل"، "Global"...).
class BulkAddProfilesScreen extends StatefulWidget {
  const BulkAddProfilesScreen({super.key});

  @override
  State<BulkAddProfilesScreen> createState() => _BulkAddProfilesScreenState();
}

class _BulkAddProfilesScreenState extends State<BulkAddProfilesScreen> {
  final _linksController = TextEditingController();
  final _groupController = TextEditingController();
  final _repository = ProfileRepository();

  int _successCount = 0;
  int _failCount = 0;
  bool _isSaving = false;
  String? _error;

  Future<void> _saveAll() async {
    final lines = _linksController.text
        .split('\n')
        .map((l) => l.trim())
        .where((l) => l.isNotEmpty)
        .toList();

    if (lines.isEmpty) {
      setState(() => _error = 'الصق رابط واحد على الأقل، كل رابط بسطر مستقل');
      return;
    }

    setState(() {
      _isSaving = true;
      _error = null;
      _successCount = 0;
      _failCount = 0;
    });

    final groupName = _groupController.text.trim().isEmpty
        ? null
        : _groupController.text.trim();

    for (final link in lines) {
      final uri = Uri.tryParse(link);
      if (uri == null || !['vless', 'vmess', 'trojan', 'hysteria', 'hysteria2', 'hy', 'hy2'].contains(uri.scheme)) {
        _failCount++;
        continue;
      }

      final parsed = LinkParser.parse(link);
      if (parsed == null) {
        _failCount++;
        continue;
      }

      final profile = VpnProfile(
        id: const Uuid().v4(),
        name: parsed.name,
        configLink: link,
        host: parsed.host,
        port: parsed.port,
        sni: parsed.sni,
        group: groupName,
      );

      await _repository.add(profile);
      _successCount++;
    }

    setState(() => _isSaving = false);

    if (!mounted) return;
    if (_failCount == 0) {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إضافة عدة بروفايلات')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _groupController,
              decoration: const InputDecoration(
                labelText: 'اسم المجموعة (اختياري، مثل: منزل، عمل، Global)',
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'الصق روابط الاشتراك هنا — رابط واحد بكل سطر:',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 6),
            Expanded(
              child: TextField(
                controller: _linksController,
                maxLines: null,
                expands: true,
                textAlignVertical: TextAlignVertical.top,
                decoration: const InputDecoration(
                  hintText: 'vless://...\nvmess://...\ntrojan://...\nhysteria2://...',
                  border: OutlineInputBorder(),
                  alignLabelWithHint: true,
                ),
              ),
            ),
            if (_error != null) ...[
              const SizedBox(height: 8),
              Text(_error!, style: const TextStyle(color: Colors.red)),
            ],
            if (_successCount > 0 || _failCount > 0) ...[
              const SizedBox(height: 8),
              Text(
                'تمت إضافة $_successCount بنجاح'
                '${_failCount > 0 ? '، وفشل $_failCount (روابط غير صالحة)' : ''}',
                style: TextStyle(
                  color: _failCount > 0 ? Colors.orange : Colors.green,
                ),
              ),
            ],
            const SizedBox(height: 16),
            FilledButton(
              onPressed: _isSaving ? null : _saveAll,
              child: _isSaving
                  ? const SizedBox(
                      height: 18,
                      width: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Text('إضافة الكل'),
            ),
          ],
        ),
      ),
    );
  }
}
