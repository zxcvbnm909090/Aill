import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/vpn_profile.dart';
import '../services/profile_repository.dart';
import '../services/link_parser.dart';

/// إضافة بروفايل عبر لصق رابط اشتراك V2Ray كامل (vless://, vmess://, trojan://).
/// يدعم استخراج الاسم تلقائيًا من vmess (base64) وvless/trojan (fragment)،
/// مع خيار تفعيل xudp (دعم UDP الكامل) لبروتوكول VLESS.
class AddProfileScreen extends StatefulWidget {
  const AddProfileScreen({super.key});

  @override
  State<AddProfileScreen> createState() => _AddProfileScreenState();
}

class _AddProfileScreenState extends State<AddProfileScreen> {
  final _nameController = TextEditingController();
  final _linkController = TextEditingController();
  final _groupController = TextEditingController();
  final _repository = ProfileRepository();
  String? _error;
  bool _enableXudp = false;
  bool _isVless = false;

  void _onLinkChanged(String value) {
    final uri = Uri.tryParse(value.trim());
    final isVless = uri?.scheme == 'vless';
    if (isVless != _isVless) {
      setState(() => _isVless = isVless);
    }

    // تعبئة الاسم تلقائيًا إذا كان الحقل فاضي
    if (_nameController.text.trim().isEmpty) {
      final parsed = LinkParser.parse(value.trim());
      if (parsed != null) {
        _nameController.text = parsed.name;
      }
    }
  }

  Future<void> _save() async {
    final name = _nameController.text.trim();
    var link = _linkController.text.trim();

    if (link.isEmpty) {
      setState(() => _error = 'الرجاء لصق رابط الاشتراك');
      return;
    }

    final uri = Uri.tryParse(link);
    if (uri == null || !['vless', 'vmess', 'trojan', 'hysteria', 'hysteria2', 'hy', 'hy2'].contains(uri.scheme)) {
      setState(() => _error = 'الرابط يجب أن يبدأ بـ vless:// أو vmess:// أو trojan:// أو hysteria2://');
      return;
    }

    // تفعيل/تعطيل xudp على رابط VLESS حسب اختيار المستخدم
    if (uri.scheme == 'vless') {
      link = LinkParser.applyXudp(link, enable: _enableXudp);
    }

    final parsed = LinkParser.parse(link);
    if (parsed == null) {
      setState(() => _error = 'تعذّر قراءة بيانات الرابط');
      return;
    }

    final finalName = name.isNotEmpty ? name : parsed.name;

    final profile = VpnProfile(
      id: const Uuid().v4(),
      name: finalName,
      configLink: link,
      host: parsed.host,
      port: parsed.port,
      sni: parsed.sni,
      group: _groupController.text.trim().isEmpty
          ? null
          : _groupController.text.trim(),
    );

    await _repository.add(profile);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إضافة بروفايل')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _linkController,
              maxLines: 4,
              onChanged: _onLinkChanged,
              decoration: const InputDecoration(
                labelText: 'رابط الاشتراك (vless://, vmess://, trojan://, hysteria2://...)',
                alignLabelWithHint: true,
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: 'اسم البروفايل (يُستخرج تلقائيًا، يمكن تعديله)',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _groupController,
              decoration: const InputDecoration(
                labelText: 'المجموعة (اختياري، مثل: منزل، عمل، Global)',
              ),
            ),
            if (_isVless) ...[
              const SizedBox(height: 8),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('تفعيل دعم UDP الكامل (xudp)'),
                subtitle: const Text(
                  'يحسّن أداء المكالمات والألعاب والبث المباشر عبر VLESS',
                ),
                value: _enableXudp,
                onChanged: (val) => setState(() => _enableXudp = val),
              ),
            ],
            if (_error != null) ...[
              const SizedBox(height: 8),
              Text(_error!, style: const TextStyle(color: Colors.red)),
            ],
            const SizedBox(height: 20),
            FilledButton(onPressed: _save, child: const Text('حفظ')),
          ],
        ),
      ),
    );
  }
}
