import 'dart:convert';

/// نتيجة تحليل رابط اشتراك V2Ray (vless/vmess/trojan).
class ParsedLinkInfo {
  final String name;
  final String host;
  final int port;
  final String? sni;

  ParsedLinkInfo({
    required this.name,
    required this.host,
    required this.port,
    this.sni,
  });
}

/// يحلل رابط الاشتراك ويستخرج منه اسم السيرفر والمضيف والمنفذ وSNI،
/// بما يدعم vmess (base64 JSON) بالإضافة إلى vless/trojan (URI عادي).
class LinkParser {
  static ParsedLinkInfo? parse(String link) {
    try {
      final uri = Uri.parse(link);

      if (uri.scheme == 'vmess') {
        final encoded = link.replaceFirst('vmess://', '').split('#').first;
        final decoded = utf8.decode(base64.decode(_padBase64(encoded)));
        final json = jsonDecode(decoded) as Map<String, dynamic>;

        return ParsedLinkInfo(
          name: (json['ps'] as String?)?.trim().isNotEmpty == true
              ? json['ps'] as String
              : 'VMess Server',
          host: json['add'] as String? ?? '',
          port: int.tryParse(json['port'].toString()) ?? 0,
          sni: (json['sni'] as String?) ?? (json['host'] as String?),
        );
      }

      if (['vless', 'trojan', 'hysteria', 'hysteria2', 'hy', 'hy2']
          .contains(uri.scheme)) {
        final rawName = uri.fragment.isNotEmpty
            ? Uri.decodeComponent(uri.fragment)
            : '${uri.scheme.toUpperCase()} Server';

        return ParsedLinkInfo(
          name: rawName,
          host: uri.host,
          port: uri.port,
          sni: uri.queryParameters['sni'],
        );
      }

      return null;
    } catch (_) {
      return null;
    }
  }

  /// يفعّل خاصية xudp (دعم UDP الكامل) على رابط VLESS بإضافة/استبدال
  /// باراميتر packetEncoding=xudp — يحسّن أداء المكالمات والألعاب والبث.
  /// لا تأثير على vmess/trojan حاليًا (xudp خاص بـ VLESS).
  static String applyXudp(String link, {required bool enable}) {
    final uri = Uri.tryParse(link);
    if (uri == null || uri.scheme != 'vless') return link;

    final params = Map<String, String>.from(uri.queryParameters);
    if (enable) {
      params['packetEncoding'] = 'xudp';
    } else {
      params.remove('packetEncoding');
    }

    final newUri = uri.replace(queryParameters: params);
    return newUri.toString();
  }

  static String _padBase64(String input) {
    final mod = input.length % 4;
    if (mod == 0) return input;
    return input + ('=' * (4 - mod));
  }
}
