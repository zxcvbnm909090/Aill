import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../models/vpn_profile.dart';
import 'link_parser.dart';

/// يجلب قائمة سيرفرات من رابط خارجي (مثل رابط GitHub Raw يستضيفه المستخدم)
/// ويحوّلها لبروفايلات V2Ray. يُستخدم لتحديث قائمة السيرفرات عن بعد
/// بدون الحاجة لإعادة بناء التطبيق.
///
/// صيغ JSON المدعومة:
/// 1) قائمة روابط نصية:
///    ["vless://...", "vmess://...", "hysteria2://..."]
///
/// 2) قائمة كائنات (تسمح بتخصيص الاسم/المجموعة):
///    [{"name": "سيرفر 1", "link": "vless://...", "group": "منزل"}, ...]
///
/// 3) كائن بمفتاح "servers" ومجموعة افتراضية لكل العناصر:
///    {"group": "Global", "servers": ["vless://...", {"name": "...", "link": "..."}]}
class SubscriptionService {
  static const _urlKey = 'subscription_url';

  Future<String?> getSavedUrl() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_urlKey);
  }

  Future<void> saveUrl(String url) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_urlKey, url);
  }

  /// يجلب الرابط ويحلل الـ JSON، ويرجّع قائمة بروفايلات جاهزة للحفظ.
  /// يرمي Exception برسالة عربية مفهومة عند أي خطأ.
  Future<List<VpnProfile>> fetchProfiles(String url) async {
    final response = await http
        .get(Uri.parse(url))
        .timeout(const Duration(seconds: 15));

    if (response.statusCode != 200) {
      throw Exception('فشل الاتصال بالرابط (كود ${response.statusCode})');
    }

    late final dynamic decoded;
    try {
      decoded = jsonDecode(response.body);
    } catch (_) {
      throw Exception('محتوى الرابط ليس JSON صالح');
    }

    final List<dynamic> rawItems;
    String? defaultGroup;

    if (decoded is List) {
      rawItems = decoded;
    } else if (decoded is Map<String, dynamic> && decoded['servers'] is List) {
      rawItems = decoded['servers'] as List;
      defaultGroup = decoded['group'] as String?;
    } else {
      throw Exception('صيغة JSON غير مدعومة');
    }

    final profiles = <VpnProfile>[];

    for (final item in rawItems) {
      String? link;
      String? name;
      String? group = defaultGroup;

      if (item is String) {
        link = item;
      } else if (item is Map<String, dynamic>) {
        link = item['link'] as String? ?? item['url'] as String?;
        name = item['name'] as String? ?? item['remark'] as String?;
        group = item['group'] as String? ?? group;
      }

      if (link == null) continue;

      final uri = Uri.tryParse(link);
      const supported = [
        'vless',
        'vmess',
        'trojan',
        'hysteria',
        'hysteria2',
        'hy',
        'hy2'
      ];
      if (uri == null || !supported.contains(uri.scheme)) continue;

      final parsed = LinkParser.parse(link);
      if (parsed == null) continue;

      profiles.add(VpnProfile(
        id: const Uuid().v4(),
        name: name ?? parsed.name,
        configLink: link,
        host: parsed.host,
        port: parsed.port,
        sni: parsed.sni,
        group: group,
      ));
    }

    if (profiles.isEmpty) {
      throw Exception('ما لقيت أي سيرفر صالح بالملف');
    }

    return profiles;
  }
}
