# Hamo VPN — هيكل تطبيق Flutter (V2Ray + SNI)

## المميزات المُهيّأة في الهيكل
- ✅ اتصال عبر V2Ray (vless/vmess/trojan) مع قراءة SNI من رابط الاشتراك
- ✅ إدارة بروفايلات (إضافة عبر رابط، حذف، اختيار)
- ✅ فحص سرعة/ping لكل بروفايل
- ✅ هيكل تحديث تلقائي (يحتاج نقطة نهاية JSON من طرفك)
- ✅ هيكل إشعارات Firebase (يحتاج ملفات إعداد مشروعك)
- ✅ دعم الوضع الليلي/الفاتح مع حفظ التفضيل

## البنية
```
lib/
├── main.dart
├── models/vpn_profile.dart
├── services/
│   ├── v2ray_service.dart      # يغلّف حزمة flutter_v2ray
│   ├── profile_repository.dart
│   ├── update_service.dart
│   └── notification_service.dart
├── providers/theme_provider.dart
├── theme/app_theme.dart
└── screens/
    ├── home_screen.dart
    ├── profiles_screen.dart
    ├── add_profile_screen.dart
    ├── speed_test_screen.dart
    └── settings_screen.dart
```

## قبل التشغيل — خطوات لازمة منك
1. **flutter pub get** بعد فتح المشروع.
2. **Firebase**: أنشئ مشروعًا على Firebase Console وأضف:
   - `android/app/google-services.json`
   - `ios/Runner/GoogleService-Info.plist`
   ثم فعّل `Firebase.initializeApp()` و `NotificationService().init()` في `main.dart`
   (هي معلّقة بتعليق `//` حاليًا).
3. **التحديث التلقائي**: بدّل `updateCheckUrl` في `update_service.dart` برابط
   JSON فعلي على سيرفرك يعيد `{ "latestVersion": "...", "apkUrl": "...", "notes": "..." }`.
4. **صلاحيات أندرويد**: أضف في `android/app/src/main/AndroidManifest.xml`:
   ```xml
   <uses-permission android:name="android.permission.INTERNET"/>
   <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
   <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
   ```
5. **حزمة flutter_v2ray**: راجع توثيقها الرسمي على pub.dev لإعداد
   `AndroidManifest.xml` (VpnService) وأي خطوات iOS إضافية — تختلف حسب
   نسخة الحزمة.

## إضافة بروفايل (رسيفر)
من شاشة "البروفايلات" اضغط + والصق رابط اشتراك V2Ray كامل مثل:
```
vless://uuid@host:443?security=tls&sni=example.com&type=ws&path=%2F#MyServer
```
الرابط يُقرأ تلقائيًا ويُستخرج منه host/port/SNI.

## ما لم يُبنى بعد (عمدًا)
- شاشة "نسيت كلمة المرور" / تسجيل دخول — لم تُطلب في المواصفات.
- نظام اشتراكات مدفوعة.
- تحميل APK فعلي من رابط التحديث (يحتاج `url_launcher` أو تنزيل مباشر).
