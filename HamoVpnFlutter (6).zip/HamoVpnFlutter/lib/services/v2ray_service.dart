import 'package:flutter/foundation.dart';
import 'package:flutter_v2ray_client/flutter_v2ray.dart';
import '../models/vpn_profile.dart';

enum VpnConnectionState { disconnected, connecting, connected, error }

/// طبقة تجريد فوق حزمة flutter_v2ray_client (تغلّف Xray-core).
/// تتعامل مع رابط الاشتراك (vless/vmess/trojan) مباشرة، بما فيها
/// باراميتر SNI المضمّن داخل الرابط لتجاوز الحجب.
///
/// الاستخدام مطابق تمامًا لتوثيق المكتبة الرسمي:
/// https://github.com/amir-zr/flutter_v2ray_client
class V2RayService extends ChangeNotifier {
  late final V2ray _v2ray;
  bool _initialized = false;

  VpnConnectionState state = VpnConnectionState.disconnected;
  String? lastError;

  // بيانات السرعة والاستهلاك اللحظية (تُحدَّث تلقائيًا أثناء الاتصال)
  int uploadSpeed = 0; // بايت/ثانية
  int downloadSpeed = 0; // بايت/ثانية
  int totalUpload = 0; // إجمالي بايت مرفوعة منذ بداية الاتصال
  int totalDownload = 0; // إجمالي بايت منزّلة منذ بداية الاتصال
  String duration = '00:00:00';

  V2RayService() {
    _v2ray = V2ray(
      onStatusChanged: (V2RayStatus status) {
        _handleStatus(status);
      },
    );
  }

  /// يجب استدعاؤها مرة واحدة قبل أي استخدام آخر (حسب توثيق المكتبة).
  Future<void> init() async {
    if (_initialized) return;
    await _v2ray.initialize(
      notificationIconResourceType: 'mipmap',
      notificationIconResourceName: 'ic_launcher',
    );
    _initialized = true;
  }

  Future<void> connect(VpnProfile profile) async {
    try {
      state = VpnConnectionState.connecting;
      notifyListeners();

      final parsed = V2ray.parseFromURL(profile.configLink);

      final hasPermission = await _v2ray.requestPermission();
      if (!hasPermission) {
        state = VpnConnectionState.error;
        lastError = 'لم يتم منح صلاحية VPN';
        notifyListeners();
        return;
      }

      await _v2ray.startV2Ray(
        remark: parsed.remark,
        config: parsed.getFullConfiguration(),
        blockedApps: null,
        bypassSubnets: null,
        proxyOnly: false,
      );
    } catch (e) {
      state = VpnConnectionState.error;
      lastError = e.toString();
      notifyListeners();
    }
  }

  Future<void> disconnect() async {
    await _v2ray.stopV2Ray();
    state = VpnConnectionState.disconnected;
    uploadSpeed = 0;
    downloadSpeed = 0;
    totalUpload = 0;
    totalDownload = 0;
    duration = '00:00:00';
    notifyListeners();
  }

  /// فحص سرعة/زمن استجابة بروفايل معيّن قبل أو أثناء الاتصال.
  Future<int> ping(VpnProfile profile) async {
    try {
      final parsed = V2ray.parseFromURL(profile.configLink);
      final delay = await _v2ray.getServerDelay(
        config: parsed.getFullConfiguration(),
      );
      return delay; // بالميلي ثانية، -1 إذا فشل الفحص
    } catch (_) {
      return -1;
    }
  }

  void _handleStatus(V2RayStatus status) {
    final raw = status.state.toUpperCase();
    if (raw.contains('CONNECTED')) {
      state = VpnConnectionState.connected;
    } else if (raw.contains('DISCONNECTED') || raw.contains('IDLE')) {
      state = VpnConnectionState.disconnected;
    }

    uploadSpeed = status.uploadSpeed;
    downloadSpeed = status.downloadSpeed;
    totalUpload = status.upload;
    totalDownload = status.download;
    duration = status.duration;

    notifyListeners();
  }
}
