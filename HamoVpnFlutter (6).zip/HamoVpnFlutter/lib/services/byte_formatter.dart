/// ينسّق قيمة بالبايت إلى صيغة مقروءة (KB/MB/GB) بخانة عشرية وحدة.
String formatBytes(int bytes) {
  if (bytes <= 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  var value = bytes.toDouble();
  var unitIndex = 0;
  while (value >= 1024 && unitIndex < units.length - 1) {
    value /= 1024;
    unitIndex++;
  }
  return '${value.toStringAsFixed(unitIndex == 0 ? 0 : 1)} ${units[unitIndex]}';
}

/// ينسّق سرعة بالبايت/ثانية إلى صيغة مقروءة، مثل "1.2 MB/s".
String formatSpeed(int bytesPerSecond) => '${formatBytes(bytesPerSecond)}/s';
