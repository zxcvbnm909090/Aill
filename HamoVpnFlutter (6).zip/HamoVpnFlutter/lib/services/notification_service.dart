import 'package:firebase_messaging/firebase_messaging.dart';

/// تهيئة إشعارات Firebase Cloud Messaging.
/// يتطلب إضافة google-services.json (أندرويد) و GoogleService-Info.plist (iOS)
/// الخاصة بمشروعك على Firebase Console — غير مضمّنة هنا.
class NotificationService {
  final FirebaseMessaging _messaging = FirebaseMessaging.instance;

  Future<void> init() async {
    await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    FirebaseMessaging.onMessage.listen((message) {
      // اعرض إشعارًا داخل التطبيق هنا (مثلاً عبر flutter_local_notifications)
      // message.notification?.title / message.notification?.body
    });

    FirebaseMessaging.onMessageOpenedApp.listen((message) {
      // التعامل مع فتح التطبيق من الإشعار (مثلاً التنقل لشاشة معينة)
    });
  }

  Future<String?> getDeviceToken() => _messaging.getToken();
}
