import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/vpn_profile.dart';

/// تخزين بروفايلات V2Ray محليًا عبر SharedPreferences.
class ProfileRepository {
  static const _key = 'vpn_profiles_json';

  Future<List<VpnProfile>> getAll() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return [];
    final list = jsonDecode(raw) as List;
    return list
        .map((e) => VpnProfile.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<void> add(VpnProfile profile) async {
    final all = await getAll();
    all.add(profile);
    await _saveAll(all);
  }

  Future<void> update(VpnProfile profile) async {
    final all = await getAll();
    final idx = all.indexWhere((p) => p.id == profile.id);
    if (idx != -1) {
      all[idx] = profile;
      await _saveAll(all);
    }
  }

  Future<void> delete(String id) async {
    final all = await getAll();
    all.removeWhere((p) => p.id == id);
    await _saveAll(all);
  }

  Future<void> _saveAll(List<VpnProfile> list) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = jsonEncode(list.map((p) => p.toJson()).toList());
    await prefs.setString(_key, raw);
  }
}
