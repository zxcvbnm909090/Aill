import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:package_info_plus/package_info_plus.dart';

/// يتحقق من وجود إصدار أحدث للتطبيق عبر نقطة نهاية خاصة بك (JSON بسيط).
/// استبدل updateCheckUrl برابط فعلي يعيد:
/// { "latestVersion": "1.2.0", "apkUrl": "https://.../app.apk", "notes": "..." }
class UpdateService {
  static const String updateCheckUrl =
      'https://example.com/hamo-vpn/version.json';

  Future<UpdateInfo?> checkForUpdate() async {
    try {
      final info = await PackageInfo.fromPlatform();
      final response = await http.get(Uri.parse(updateCheckUrl));
      if (response.statusCode != 200) return null;

      final data = jsonDecode(response.body) as Map<String, dynamic>;
      final latest = data['latestVersion'] as String;

      if (_isNewer(latest, info.version)) {
        return UpdateInfo(
          latestVersion: latest,
          apkUrl: data['apkUrl'] as String? ?? '',
          notes: data['notes'] as String? ?? '',
        );
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  bool _isNewer(String latest, String current) {
    final l = latest.split('.').map(int.parse).toList();
    final c = current.split('.').map(int.parse).toList();
    for (var i = 0; i < l.length; i++) {
      final cv = i < c.length ? c[i] : 0;
      if (l[i] > cv) return true;
      if (l[i] < cv) return false;
    }
    return false;
  }
}

class UpdateInfo {
  final String latestVersion;
  final String apkUrl;
  final String notes;

  UpdateInfo({
    required this.latestVersion,
    required this.apkUrl,
    required this.notes,
  });
}
