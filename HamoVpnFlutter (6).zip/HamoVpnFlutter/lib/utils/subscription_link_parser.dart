import 'dart:convert';

/// نتيجة تحليل رابط اشتراك V2Ray (للعرض في الواجهة فقط — التحليل الفعلي
/// لإنشاء إعدادات الاتصال يتم داخل v2ray_service.dart عبر V2ray.parseFromURL).
class ParsedLinkInfo {
  final String? remark;
  final String host;
  final int port;
  final String? sni;

  const ParsedLinkInfo({
    this.remark,
    required this.host,
    required this.port,
    this.sni,
  });
}

class SubscriptionLinkParser {
  /// يدعم vless://, trojan://, ss:// (روابط URI قياسية)
  /// وكذلك vmess:// (مُشفّر بصيغة base64 تحتوي JSON).
  static ParsedLinkInfo? parse(String link) {
    final trimmed = link.trim();

    if (trimmed.startsWith('vmess://')) {
      return _parseVmess(trimmed);
    }

    // vless, trojan, ss, hysteria, hysteria2... كلها روابط URI قياسية
    try {
      final uri = Uri.parse(trimmed);
      if (uri.host.isEmpty) return null;

      return ParsedLinkInfo(
        remark: uri.fragment.isNotEmpty ? Uri.decodeComponent(uri.fragment) : null,
        host: uri.host,
        port: uri.port,
        sni: uri.queryParameters['sni'],
      );
    } catch (_) {
      return null;
    }
  }

  static ParsedLinkInfo? _parseVmess(String link) {
    try {
      final base64Part = link.substring('vmess://'.length);
      final decodedBytes = base64Decode(_normalizeBase64(base64Part));
      final decodedJson = utf8.decode(decodedBytes);
      final map = jsonDecode(decodedJson) as Map<String, dynamic>;

      final host = (map['add'] as String?)?.trim() ?? '';
      final port = int.tryParse(map['port']?.toString() ?? '') ?? 0;
      final remark = (map['ps'] as String?)?.trim();
      // sni غالبًا بحقل 'sni' أو يُستخدم 'host' (ترويسة ws/h2) كـ fallback
      final sni = (map['sni'] as String?) ?? (map['host'] as String?);

      if (host.isEmpty) return null;

      return ParsedLinkInfo(
        remark: remark,
        host: host,
        port: port,
        sni: sni,
      );
    } catch (_) {
      return null;
    }
  }

  /// base64 في روابط vmess أحيانًا بدون padding ('=') في النهاية.
  static String _normalizeBase64(String input) {
    var output = input.replaceAll('-', '+').replaceAll('_', '/');
    final mod = output.length % 4;
    if (mod != 0) {
      output += '=' * (4 - mod);
    }
    return output;
  }
}
