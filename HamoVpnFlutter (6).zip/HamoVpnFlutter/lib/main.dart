import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';

import 'providers/theme_provider.dart';
import 'services/v2ray_service.dart';
import 'services/notification_service.dart';
import 'theme/app_theme.dart';
import 'screens/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // يتطلب ملفات إعداد Firebase الخاصة بمشروعك (غير مضمّنة في هذا الهيكل)
  // await Firebase.initializeApp();

  final themeProvider = ThemeProvider();
  await themeProvider.load();

  final v2rayService = V2RayService();
  await v2rayService.init();

  // await NotificationService().init();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: themeProvider),
        ChangeNotifierProvider.value(value: v2rayService),
      ],
      child: const HamoVpnApp(),
    ),
  );
}

class HamoVpnApp extends StatelessWidget {
  const HamoVpnApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<ThemeProvider>();

    return MaterialApp(
      title: 'Hamo VPN',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: themeProvider.mode,
      locale: const Locale('ar'),
      home: const HomeScreen(),
    );
  }
}
