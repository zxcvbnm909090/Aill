import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/vpn_profile.dart';
import '../services/profile_repository.dart';
import '../services/v2ray_service.dart';

class SpeedTestScreen extends StatefulWidget {
  const SpeedTestScreen({super.key});

  @override
  State<SpeedTestScreen> createState() => _SpeedTestScreenState();
}

class _SpeedTestScreenState extends State<SpeedTestScreen> {
  final _repository = ProfileRepository();
  List<VpnProfile> _profiles = [];
  final Map<String, int?> _results = {};
  bool _testing = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final all = await _repository.getAll();
    setState(() => _profiles = all);
  }

  Future<void> _testAll() async {
    final v2ray = context.read<V2RayService>();
    setState(() => _testing = true);

    for (final profile in _profiles) {
      final delay = await v2ray.ping(profile);
      setState(() => _results[profile.id] = delay == -1 ? null : delay);
    }

    setState(() => _testing = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('فحص السرعة')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: FilledButton.icon(
              onPressed: _testing ? null : _testAll,
              icon: _testing
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.speed),
              label: Text(_testing ? 'جاري الفحص...' : 'فحص كل البروفايلات'),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _profiles.length,
              itemBuilder: (context, index) {
                final p = _profiles[index];
                final result = _results[p.id];
                return ListTile(
                  title: Text(p.name),
                  subtitle: Text(p.host),
                  trailing: Text(
                    result == null
                        ? (_results.containsKey(p.id) ? 'فشل' : '—')
                        : '$result ms',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: result == null
                          ? Colors.red
                          : result < 300
                              ? Colors.green
                              : Colors.orange,
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
