import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../services/update_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _updateService = UpdateService();
  bool _checkingUpdate = false;

  Future<void> _checkUpdate() async {
    setState(() => _checkingUpdate = true);
    final info = await _updateService.checkForUpdate();
    setState(() => _checkingUpdate = false);

    if (!mounted) return;

    if (info == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('أنت تستخدم آخر إصدار')),
      );
    } else {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text('تحديث جديد: ${info.latestVersion}'),
          content: Text(info.notes.isEmpty ? 'يتوفر إصدار أحدث من التطبيق' : info.notes),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('لاحقًا')),
            FilledButton(
              onPressed: () {
                // افتح info.apkUrl عبر url_launcher في التنفيذ النهائي
                Navigator.pop(context);
              },
              child: const Text('تحديث الآن'),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<ThemeProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        children: [
          SwitchListTile(
            title: const Text('الوضع الليلي'),
            value: themeProvider.mode == ThemeMode.dark,
            onChanged: (val) => themeProvider.toggle(val),
          ),
          ListTile(
            title: const Text('التحقق من وجود تحديث'),
            trailing: _checkingUpdate
                ? const SizedBox(
                    width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.chevron_left),
            onTap: _checkingUpdate ? null : _checkUpdate,
          ),
        ],
      ),
    );
  }
}
