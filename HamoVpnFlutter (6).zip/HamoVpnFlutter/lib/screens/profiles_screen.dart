import 'package:flutter/material.dart';
import '../models/vpn_profile.dart';
import '../services/profile_repository.dart';
import 'add_profile_screen.dart';
import 'bulk_add_profiles_screen.dart';

class ProfilesScreen extends StatefulWidget {
  const ProfilesScreen({super.key});

  @override
  State<ProfilesScreen> createState() => _ProfilesScreenState();
}

class _ProfilesScreenState extends State<ProfilesScreen> {
  final _repository = ProfileRepository();
  final _searchController = TextEditingController();

  List<VpnProfile> _allProfiles = [];
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final all = await _repository.getAll();
    setState(() => _allProfiles = all);
  }

  bool _isXudpEnabled(VpnProfile p) {
    final uri = Uri.tryParse(p.configLink);
    return uri?.queryParameters['packetEncoding'] == 'xudp';
  }

  /// يجمّع البروفايلات حسب اسم المجموعة (البروفايلات بدون مجموعة تحت "عام").
  Map<String, List<VpnProfile>> _groupedProfiles() {
    final filtered = _searchQuery.isEmpty
        ? _allProfiles
        : _allProfiles
            .where((p) =>
                p.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
                p.host.toLowerCase().contains(_searchQuery.toLowerCase()) ||
                (p.group?.toLowerCase().contains(_searchQuery.toLowerCase()) ??
                    false))
            .toList();

    final Map<String, List<VpnProfile>> grouped = {};
    for (final p in filtered) {
      final key = (p.group?.trim().isNotEmpty ?? false) ? p.group! : 'عام';
      grouped.putIfAbsent(key, () => []).add(p);
    }
    return grouped;
  }

  @override
  Widget build(BuildContext context) {
    final grouped = _groupedProfiles();

    return Scaffold(
      appBar: AppBar(
        title: const Text('البروفايلات'),
        actions: [
          IconButton(
            icon: const Icon(Icons.playlist_add),
            tooltip: 'إضافة عدة بروفايلات دفعة واحدة',
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const BulkAddProfilesScreen()),
              );
              _refresh();
            },
          ),
          IconButton(
            icon: const Icon(Icons.add),
            tooltip: 'إضافة بروفايل واحد',
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AddProfileScreen()),
              );
              _refresh();
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _searchController,
              onChanged: (v) => setState(() => _searchQuery = v),
              decoration: InputDecoration(
                hintText: 'ابحث باسم السيرفر أو المجموعة...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                isDense: true,
              ),
            ),
          ),
          Expanded(
            child: _allProfiles.isEmpty
                ? const Center(child: Text('لا يوجد بروفايلات بعد. اضغط + للإضافة'))
                : grouped.isEmpty
                    ? const Center(child: Text('لا نتائج مطابقة للبحث'))
                    : ListView(
                        children: grouped.entries.map((entry) {
                          return _buildGroupSection(entry.key, entry.value);
                        }).toList(),
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildGroupSection(String groupName, List<VpnProfile> profiles) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: Text(
            groupName,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 13,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
        ),
        ...profiles.map(_buildProfileTile),
      ],
    );
  }

  Widget _buildProfileTile(VpnProfile p) {
    final uri = Uri.tryParse(p.configLink);
    final protocol = uri?.scheme.toUpperCase() ?? '';
    final xudp = _isXudpEnabled(p);

    return ListTile(
      leading: const Icon(Icons.dns_outlined),
      title: Text(p.name),
      subtitle: Text(
        '${p.host}:${p.port} • $protocol'
        '${p.sni != null ? ' • SNI: ${p.sni}' : ''}'
        '${xudp ? ' • UDP✓' : ''}',
      ),
      trailing: IconButton(
        icon: const Icon(Icons.delete_outline),
        onPressed: () async {
          await _repository.delete(p.id);
          _refresh();
        },
      ),
      onTap: () => Navigator.pop(context, p),
    );
  }
}
